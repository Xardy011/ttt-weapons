SWEP.Base = "weapon_tttbase"
SWEP.HoldType = "fist"
SWEP.ViewModelFOV = 57.688442211055
SWEP.ViewModelFlip = false
SWEP.UseHands = true 
SWEP.ViewModel = "models/requiem/w_arrow.mdl"
SWEP.WorldModel = "models/requiem/w_arrow.mdl"
SWEP.ShowViewModel = true
SWEP.ShowWorldModel = true
SWEP.ViewModelBoneMods = {
	["ValveBiped.Bip01_R_Hand"] = { scale = Vector(1, 1, 1), pos = Vector(0, -2.037, -5.37), angle = Angle(-61.112, 0, 0) }
}
SWEP.PrintName = "Requiem Arrow"
SWEP.Kind = WEAPON_EQUIP1
SWEP.Slot = 4
SWEP.Icon = "vgui/ttt/ttt_requiem"
SWEP.CanBuy = { ROLE_TRAITOR }
SWEP.LimitedStock = true
SWEP.EquipMenuData = {
	type = "Weapon",
	desc = "This is... Requiem."
}
SWEP.AllowDrop = true

if SERVER then
	resource.AddFile("materials/vgui/ttt/ttt_requiem.vmt")	
end

function SWEP:PrimaryAttack()
	timer.Create("RequiemDisable", 120, 1, function()
		if SERVER then
			Owner:EmitSound(Sound("requiem/requiemend.mp3"), 75, 100, 1)
    		Owner:ChatPrint("Requiem has ended...")
    		Owner:SetMaxHealth(100)
    		Owner:SetWalkSpeed(220)
    		Owner:SetHealth(100)
    	end
    end)

    Owner = self:GetOwner()
    Owner:EmitSound(Sound("requiem/requiemstart.mp3"), 75, 100, 1)
    for k,v in pairs(player.GetAll()) do
    v:EmitSound(Sound("requiem/requiemstartall.mp3"), 75, 100, 1)
    Owner:StripWeapon(tostring(Owner:GetActiveWeapon():GetClass())) 
    for k,v in pairs(player.GetAll()) do
    	v:ChatPrint(Owner:GetName().." used Requiem Arrow, watch out!")
end

    if SERVER then
    	Owner:SetMaxHealth(500)
    	Owner:SetWalkSpeed(500)
    	Owner:SetHealth(500)
    end

    	

    		
    	
   
end
end